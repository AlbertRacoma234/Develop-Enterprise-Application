package com.abccarportal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AbcCarPortalApplication {

	public static void main(String[] args) {
		SpringApplication.run(AbcCarPortalApplication.class, args);
	}

}
